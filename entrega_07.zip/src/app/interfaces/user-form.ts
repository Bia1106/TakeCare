
export interface UserForm {
    form_sair_casa: string;
    form_trasporte: string;
    form_temperatura1: string;
    form_temperatura2: string;
    item:string;
    item2:string;
    item3:string;
  }