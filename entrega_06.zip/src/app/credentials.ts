export const firebaseConfig = {
    apiKey: "AIzaSyCAG4A4gj-LTLv5vbbTbF7gLB8pQv_PS9c",
    authDomain: "take-care-5ae42.firebaseapp.com",
    databaseURL: "https://take-care-5ae42.firebaseio.com",
    projectId: "take-care-5ae42",
    storageBucket: "take-care-5ae42.appspot.com",
    messagingSenderId: "601963020597",
    appId: "1:601963020597:web:4ed93352c57684ca9b4c7c",
    measurementId: "G-LG0HSWT9BE"
  };