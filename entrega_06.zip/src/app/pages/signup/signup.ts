import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserData } from '../../providers/user-data';

import { UserOptions } from '../../interfaces/user-options';



@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
  styleUrls: ['./signup.scss'],
})
export class SignupPage {
  signup: UserOptions = { username: '', password: '', nome: '',email:'', idade: 0, dataNasc: '', tipoSangue: '', sexo: ''};
  submitted = false;
  constructor(
    public router: Router,
    public userData: UserData
  ) { }

  onSignup() {
      this.userData.cadastrar(this.signup).then((data) => {
        console.log('cliente cadastrado', data);
        this.router.navigateByUrl('/app/tabs/map');
      }).catch((erro) => {
        console.error(erro);
      })
  }
}